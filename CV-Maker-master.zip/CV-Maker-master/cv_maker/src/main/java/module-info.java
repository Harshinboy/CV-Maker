module testtopdf {
    requires javafx.fxml;
    requires javafx.controls;
    requires kernel;
    requires layout;
    requires html2pdf;

    opens sample;
}